import type { Calendar } from "../../context/ModerationContext";

export type ModerationCampaignCreateResponse = { id: string };
export type ModerationCampaignUpdateResponse = { id: string };

export type ModerationCampaignItem = {
  id: string;
  user: { id: string; email: string };
  name: string;
  objective?: string;
  description?: string;
  leadDefinition?: string;
  audience?: {
    geo?: Array<{
      countryId?: string;
      stateId?: string;
      city?: string;
      postalCode?: string;
    }>;
    demographics?: {
      age?: string[];
      gender?: string;   // 'M' | 'F' | 'all' (backend returns 'M'|'F' in sample)
      nse?: string[];
    };
    culturalInterests?: string;
  };
  communicationTone?: string;        // e.g. "other"
  communicationToneOther?: string;   // e.g. "Tonito"
  startAt?: string;                  // ISO
  endAt?: string;                    // ISO
  channels?: Array<"instagram" | "facebook" | "whatsapp" | "webchat">;
  status?: string;                   // e.g. "draft"
  assistantName?: string;
  greeting?: string;
  conversationLogic?: string;
  knowHow?: Array<{ question: string; answer: string }>;
  respondOnlyRelatedTo?: string;     // joined string
  humanEscalation?: string[];
  escalationContactNumber?: string;
  createdAt: string;
  updatedAt: string;
  whatsappStatus?: {
    qrScanned: boolean,
    qrScannedAt: string | null;
    qrScannedBy: string | null;
    qrScannedByPhone: string | null;
  },
};

export type ModerationCampaignSearchResponse = {
  page: number;
  pageSize: number;
  sortField: string;
  sortOrder: "ASC" | "DESC";
  total: number;
  items: ModerationCampaignItem[];
};

export type StepOneCtx = {
  name?: string;
  goal?: string;
  summary?: string;
  leadDefinition?: string;
  audience: {
    geo: {
      countryIds?: string[];
      country?: string;
      countryCode?: string;
      region?: string;
      regionCode?: string;
      city?: string;
      postalCode?: string;
    };
    demographic: {
      ageGroups: string[];
      gender?: string;
      socioeconomic: string[];
    };
    cultural?: string;
  };
  tone?: string;
  customTone?: string;
};

export type AssistantSettingsPayload = {
  assistantName?: string;
  greeting?: string;
  conversationLogic?: string;
  voiceConfig?: string;
  knowHow?: Array<{ question: string; answer: string }>;
  respondOnlyRelatedTo?: string;
  humanEscalation?: string[];
  escalationContactNumber?: string;

  calendars?: Calendar[]
};

export type SearchParams = {
  userId: string;
  page?: number;
  pageSize?: number;
  sortField?: string;
  sortOrder?: "ASC" | "DESC";
};

export type ExtractQAResponse = { question: string; answer: string }[];

export type CampaignStatus = "draft" | "active" | "inactive" | "archived";

export type ExtractedQA = { question: string; answer: string };

export type ActivateWhatsappBotResponse = {
  success: boolean;
  message: string;
  campaignId: string;
  agentId: string;
  agentName: string;
  userId: string;
  campaignName: string;
  channels: string[];
  qrGenerated: boolean;
};

export type Lead = {
  id: string;
  name: string;
  summary: string;
  score: number;
  channel?: "whatsapp" | "instagram" | "facebook" | "email" | "x" | "unknown";
  channelLink?: string;
  requiresAction?: boolean;
  /** Raw conversationId from backend (preferred for updates) */
  conversationId?: string;
  /** Campaign id (sometimes returned by backend) */
  campaignId?: string;
  status?: LeadStatus;
  customStatusLabel?: string;
  area?: string;
  username?: string | null;
  profilePic?: string | null;
  contactNumber?: string | null;
  /** Manual timeline of follow-ups. Not the AI interest.nextAction */
  nextAction?: Array<{
    _id?: string;
    text: string;
    createdAt: string;
    createdBy?: string;
  }>;
};

export type LeadStatus =
  | "new"
  | "on_following"
  | "contacted"
  | "negotiating"
  | "closed_won"
  | "closed_lost"
  | "custom";


export interface UpdateModerationCampaignLeadStatusArgs {
  campaignId: string;
  conversationId: string;
  status: LeadStatus;
  customStatusLabel?: string;
}