import type { ToolSpec } from "../../types";

export const validationSchema: ToolSpec[] = [
  {
    type: "function",
    name: "checkModerationStepStatus",
    description:
      "Devuelve qué campos faltan para completar un paso. Si no se indica 'step', devuelve un resumen de todos.",
    parameters: {
      type: "object",
      properties: {
        step: { type: "number", description: "Paso (0=Datos, 1=Canales, etc.). Opcional." },
      },
      additionalProperties: false,
    },
  },
  {
    type: "function",
    name: "goToNextModerationStep",
    description:
      "Intenta pasar al siguiente paso. Primero valida el paso actual; si falta algo, responde los motivos y no avanza. Si ya está en el último (3), avisa que es el último y sugiere finalizar la campaña.",
    parameters: { type: "object", properties: {}, additionalProperties: false },
  },
  {
    type: "function",
    name: "goToPrevModerationStep",
    description:
      "Vuelve al paso anterior. Si ya está en el primero (0), avisa que no puede retroceder más.",
    parameters: { type: "object", properties: {}, additionalProperties: false },
  },
  {
    type: "function",
    name: "goNextNModerationStep",
    description:
      "Avanza al paso solicitado. Acepta step (0..3), n (cantidad a avanzar) o topic (texto como 'canales de comunicación', 'saludo inicial', 'base de conocimiento', etc.). Valida y guarda antes de avanzar.",
    parameters: {
      type: "object",
      properties: {
        step: {
          type: "number",
          description: "Paso objetivo (humano 1..4 o índice 0..3). 1=Datos, 2=Canales, 3=Reglas, 4=Revisión.",
        },
        n: { type: "number", description: "Cantidad de pasos a avanzar desde el actual." },
        topic: { type: "string", description: "Tópico que el usuario quiere editar. Se mapea al paso." },
      },
      additionalProperties: false,
    },
  },
  {
    type: "function",
    name: "goPrevNModerationStep",
    description:
      "Retrocede al paso solicitado. Acepta step (0..3), n (cantidad a retroceder) o topic (texto como 'nombre', 'objetivo', 'canales', 'calendario', etc.). No valida para retroceder.",
    parameters: {
      type: "object",
      properties: {
        step: {
          type: "number",
          description: "Paso objetivo (humano 1..4 o índice 0..3). 1=Datos, 2=Canales, 3=Reglas, 4=Revisión.",
        },
        n: { type: "number", description: "Cantidad de pasos a retroceder desde el actual." },
        topic: { type: "string", description: "Tópico que el usuario quiere editar. Se mapea al paso." },
      },
      additionalProperties: false,
    },
  }

];
